/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

import controlador.ControlPersona;
import controlador.ControladorMenuPrincipal;
import modelo.ModeloPersona;
import vista.VistaPersonas;
import vista.VistaPrincipal;


/**
 *
 * @author alejo
 */
public class Mvc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        VistaPersonas vista = new VistaPersonas();
//        ModeloPersona model = new ModeloPersona();
//         ViewMenuPrincipal vista = new ViewMenuPrincipal();
        
//        ControlPersona control = new ControlPersona(model, vista);
//        control.iniciacontrol();
         VistaPrincipal vista = new VistaPrincipal();
         ControladorMenuPrincipal controlador= new ControladorMenuPrincipal(vista);    
         controlador.iniciaControl();
         
    }
   
    
}
